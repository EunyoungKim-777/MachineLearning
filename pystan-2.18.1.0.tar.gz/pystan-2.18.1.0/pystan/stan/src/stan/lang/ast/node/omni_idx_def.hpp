#ifndef STAN_LANG_AST_NODE_OMNI_IDX_DEF_HPP
#define STAN_LANG_AST_NODE_OMNI_IDX_DEF_HPP

#include <stan/lang/ast.hpp>

namespace stan {
  namespace lang {

    omni_idx::omni_idx() { }

  }
}
#endif
